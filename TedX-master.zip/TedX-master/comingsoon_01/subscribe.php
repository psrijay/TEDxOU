<?php
require 'PHPMailer-master/PHPMailerAutoload.php';
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tedx";

$mailid = $_POST['email'];

$mail = new PHPMailer;

$mail->isSMTP();                            // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                     // Enable SMTP authentication
$mail->Username = 'innoshop.laxman@gmail.com';          // SMTP username
$mail->Password = 'laxman133710650523411878125546'; // SMTP password
$mail->SMTPSecure = 'tls';                  // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                          // TCP port to connect to

$mail->setFrom('innoshop.laxman@gmail.com', 'TEDxOsmaniaU');
$mail->addReplyTo($mailid, 'TEDxOsmaniaU');
$mail->addAddress($mailid);   // Add a recipient

$mail->isHTML(true);  // Set email format to HTML

$bodyContent = '<h3>Hello, Greetings from TEDxOsmaniaU</h3>';
$bodyContent .= '<p>As per your subscription to our Coming Soon website, We give an Update to you regarding our Website.</p>';

$mail->Subject = 'Email from Localhost by TEDxOsmaniaU';
$mail->Body    = $bodyContent;
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO notify (Id, MailId,date_of_subscribe)
VALUES ('','$mailid',NOW())";

if (mysqli_query($conn, $sql) && $mail->send()) {
 ?>
 <script type="text/javascript" src="https://code.jquery.com/jquery-1.8.2.js"></script>
<style type="text/css">
#overlay {
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background-color: #000;
filter:alpha(opacity=70);
-moz-opacity:0.7;
-khtml-opacity: 0.7;
opacity: 0.7;
z-index: 100;
display: none;
}
.cnt223 a{
text-decoration: none;
}
.popup{
width: 100%;
margin: 0 auto;
display: none;
position: fixed;
z-index: 101;
}
.cnt223{
min-width: 600px;
width: 600px;
min-height: 150px;
margin: 100px auto;
background: #f3f3f3;
position: relative;
z-index: 103;
padding: 15px 35px;
border-radius: 5px;
box-shadow: 0 2px 5px #000;
}
.cnt223 .x:hover{
cursor: pointer;
}
</style>
<script type='text/javascript'>
$(function(){
var overlay = $('<div id="overlay"></div>');
overlay.show();
overlay.appendTo(document.body);
$('.popup').show();
$('.close').click(function(){
$('.popup').hide();
overlay.appendTo(document.body).remove();
return false;
});
$('.x').click(function(){
$('.popup').hide();
overlay.appendTo(document.body).remove();
return false;
});
});
</script>
<div class='popup'>
<div class='cnt223'>
<h1>TEDx OsmaniaU</h1>
<p>
Thank you for Subscribing Us. You will be Notified about our Updates very Soon!!
<br/>
<br/>
<a href='index.php'>Close</a>
</p>
</div>
</div>
<?php
} else {
?>
 <script type="text/javascript" src="https://code.jquery.com/jquery-1.8.2.js"></script>
<style type="text/css">
#overlay {
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background-color: #000;
filter:alpha(opacity=70);
-moz-opacity:0.7;
-khtml-opacity: 0.7;
opacity: 0.7;
z-index: 100;
display: none;
}
.cnt223 a{
text-decoration: none;
}
.popup{
width: 100%;
margin: 0 auto;
display: none;
position: fixed;
z-index: 101;
}
.cnt223{
min-width: 600px;
width: 600px;
min-height: 150px;
margin: 100px auto;
background: #f3f3f3;
position: relative;
z-index: 103;
padding: 15px 35px;
border-radius: 5px;
box-shadow: 0 2px 5px #000;
}
.cnt223 .x:hover{
cursor: pointer;
}
</style>
<script type='text/javascript'>
$(function(){
var overlay = $('<div id="overlay"></div>');
overlay.show();
overlay.appendTo(document.body);
$('.popup').show();
$('.close').click(function(){
$('.popup').hide();
overlay.appendTo(document.body).remove();
return false;
});
$('.x').click(function(){
$('.popup').hide();
overlay.appendTo(document.body).remove();
return false;
});
});
</script>
<div class='popup'>
<div class='cnt223'>
<h1>TEDx OsmaniaU</h1>
<p>
Seems like the Email is already registered or Invalid Email!!
<br/>
<br/>
<a href='index.php'>Close</a>
</p>
</div>
</div>
<?php
}

mysqli_close($conn);
?>