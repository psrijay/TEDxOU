<?php
session_start();

require 'dbconfig/teams.php';

if(isset($_POST['loginbtn']))
{
    $mail   = $_POST['mail'];
    $passwrd = $_POST['passwd'];

    $mp   = md5($passwrd);
    $sql  = "select * from login where mail='$mail' AND passwd='$mp'";
    $qrun = mysqli_query($conn,$sql);
    $n    = mysqli_num_rows($qrun);

    if( $n == 1)
    {
        $_SESSION['mail'] = $mail;

        echo '<script type="text/javascript">
        alert("Login Successful");</script>';

        header('Location: ../../payment/ticket.php');
    }
    else
    {
        echo '<script type="text/javascript">
        alert("Invalid email or password");
        window.location.href="login_reg.php";
        </script>';
    }
}

if(isset($_POST['regbtn']))
{
    $name     = $_POST['name'];
    $mail     = $_POST['mail'];
    $number   = $_POST['mobile'];
    $username = $_POST['user'];
    $passwrd  = $_POST['passwd'];
    $confirmpassword = $_POST['cnfrmpasswd'];

    if($passwrd == $confirmpassword)
    {
        $mpasswd= md5($passwrd);

        $sql = "insert into login values(NULL,'$name','$mail','$number','$username','$mpasswd')";
        $qrun = mysqli_query($conn,$sql);
        
        if($qrun)
        {
            $_SESSION['email']=$mail;
            
            echo '<script type="text/javascript">
        alert("Account Created Successfully");
        window.location.href="../../payment/";
        </script>';
        }
        else
        {
            echo '<script type="text/javascript">
        alert("Account could not be created \n Contact Admin");
        window.location.href="login_reg.php";
        </script>';
        }
    }
    else
    {
        echo '<script type="text/javascript">
        alert("Passwords donot match");
        window.location.href="login_reg.php";
        </script>';
    }
}