<?php
echo(file_get_contents("webpages/lib.html"));
?>

<div class="banner1">

<?php
echo(file_get_contents("webpages/header.html"));

?>
<?php
$conn1=mysqli_connect("localhost","root","","event") or die(mysqli_error($conn1));
$select_query1="select * from events";
$select_query_result1=mysqli_query($conn1,$select_query1) or die(mysqli_error($conn1));
        ?>
    
    
    <div class="banner1" >
    <div class="bx">
        <span class="text1"> <?php $row=mysqli_fetch_array($select_query_result1);
                                     echo $row["etheme"];?></span>
        <span class="text2"><?php
                                     echo $row["edate"];?></span>
    </div>
    <button style="position: relative; left: 1200px; top: 500px" class="btn btn-lg btn-danger">Grab your Tickets <span class="badge"> >> </span></button>
</div>

    
    
    
<div class="banner2">



<div class="container-fluid">
<div class="row">
    <div class="col-md-10 col-md-offset-1">
<div class="wrapper">
  
    <div class="card1">
    <h3 class="card-title"><center> <?php 
                                     echo $row["etheme"]; ?></center></h3><br>
<p class="card-content">
    
                                    <?php 
                                     echo $row["edesc"]; ?>                  
</p>
</div>
</div>
    </div></div>
    <div class="name">
        <center>SPEAKERS  2019 </center>
    </div>
    
    
    
 <?php
$conn=mysqli_connect("localhost","root","","event") or die(mysqli_error($conn));
$select_query="select * from speaker";
$select_query_result=mysqli_query($conn,$select_query) or die(mysqli_error($conn));
        ?>
   
    <div class="cont">
      
         <div class="box1">
             <div class="imgbox">
                 <?php
                 $row=mysqli_fetch_array($select_query_result);?>
                 <img src="<?php echo $row["simg"]; ?>" > 
             </div>
             <div class="details">
                 <div class="content">
                     <h2><?php echo $row["sname"];?></h2><p> <?php echo $row["sdesc"];?></p>
                 </div>
             </div>
         </div>  
          <div class="box1">
           <div class="imgbox">
                <?php
                 $row=mysqli_fetch_array($select_query_result);?>
                 <img src="<?php echo $row["simg"]; ?>" > 
             </div>
             <div class="details">
                 <div class="content">
                 <h2><?php echo $row["sname"];?></h2><p><?php echo $row["sdesc"];?> </p>
                 </div>
             </div>
          </div>
           <div class="box1">
                <div class="imgbox">
                <?php
                 $row=mysqli_fetch_array($select_query_result);?>
                 <img src="<?php echo $row["simg"]; ?>" > 
             </div>
             <div class="details">
                 <div class="content">
                 <h2> <?php echo $row["sname"];?></h2><p><?php echo $row["sdesc"];?> </p>
                 </div>
             </div>
           </div>
            <div class="box1">
             <div class="imgbox">
                <?php
                 $row=mysqli_fetch_array($select_query_result);?>
                 <img src="<?php echo $row["simg"]; ?>" > 
             </div>
             <div class="details">
                 <div class="content">
                 <h2><?php echo $row["sname"];?></h2><p><?php echo $row["sdesc"];?> </p>
                 </div>
             </div>
            </div>
             <div class="box1">
                  <div class="imgbox">
                   <?php
                 $row=mysqli_fetch_array($select_query_result);?>
                 <img src="<?php echo $row["simg"]; ?>" > 
             </div>
             <div class="details">
                 <div class="content">
                 <h2><?php echo $row["sname"];?></h2><p><?php echo $row["sdesc"];?> </p>
                 </div>
             </div>
             </div>
              <div class="box1">
               <div class="imgbox">
                 <?php
                 $row=mysqli_fetch_array($select_query_result);?>
                 <img src="<?php echo $row["simg"]; ?>" > 
             </div>
             <div class="details">
                 <div class="content">
                 <h2><?php echo $row["sname"];?></h2><p><?php echo $row["sdesc"];?> </p>
                 </div>
             </div>
              </div>
               <div class="box1">
                <div class="imgbox">
                   <?php
                 $row=mysqli_fetch_array($select_query_result);?>
                 <img src="<?php echo $row["simg"]; ?>" >  
             </div>
             <div class="details">
                 <div class="content">
                 <h2><?php echo $row["sname"];?></h2><p><?php echo $row["sdesc"];?> </p>
                 </div>
             </div>
               </div>
                <div class="box1">
                 <div class="imgbox">
                   <?php
                 $row=mysqli_fetch_array($select_query_result);?>
                 <img src="<?php echo $row["simg"]; ?>" > 
             </div>
             <div class="details">
                 <div class="content">
                 <h2><?php echo $row["sname"];?></h2><p><?php echo $row["sdesc"];?> </p>
                 </div>
             </div>
                </div>
    </div>
   </div>
    <?php
echo(file_get_contents("webpages/footer.html"));
?>