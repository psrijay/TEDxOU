<link href="css/style.css" type="text/css" rel="stylesheet" media="all">

<div class = "banner-about">    
<?php
echo(file_get_contents("webpages/header.html"));
echo(file_get_contents("webpages/login_reg.html"));
?>