<?php
echo(file_get_contents("webpages/lib.html"));

?>
<style type="text/css">
.banner{ 
	background:url(./images/ted_bg.jpg)no-repeat center bottom;
	-webkit-background-size:cover; 
	-moz-background-size:cover; 
	-o-background-size:cover;
	-ms-background-size:cover; 	
	background-size:cover; 
	min-height: 720px;
	position:relative;
	clip-path: polygon( 0 0, 100% 0, 100% 100%, 0 calc(100% - 5vw) );
    -webkit-clip-path: polygon( 0 0, 100% 0, 100% 100%, 0 calc(100% - 5vw) );
    -o-clip-path: polygon( 0 0, 100% 0, 100% 100%, 0 calc(100% - 5vw) );
    -ms-clip-path: polygon( 0 0, 100% 0, 100% 100%, 0 calc(100% - 5vw) );
    -moz-clip-path: polygon( 0 0, 100% 0, 100% 100%, 0 calc(100% - 5vw) );
}
</style>
<div class="banner"> 
<?php
echo(file_get_contents("webpages/header.html"));
echo(file_get_contents("webpages/index.html"));
echo(file_get_contents("webpages/footer.html"));
?>