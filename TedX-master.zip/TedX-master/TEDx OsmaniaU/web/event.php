<?php
echo(file_get_contents("webpages/lib.html"));
?>

<div class="banner1">
<?php
echo(file_get_contents("webpages/header.html"));
echo(file_get_contents("webpages/events1.html"));
?>

<div class="banner2">
<?php
echo(file_get_contents("webpages/events2.html"));
echo(file_get_contents("webpages/footer.html"));
?>