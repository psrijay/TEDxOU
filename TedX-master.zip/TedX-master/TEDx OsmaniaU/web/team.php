<?php
require "dbconfig/teams.php";

echo(file_get_contents("webpages/lib.html"));

echo '<body>';
echo '<div class="header_menu">';
echo(file_get_contents("webpages/header.html"));
echo '</div>';

echo '<div class="team_gd2">';
echo(file_get_contents("webpages/team.html"));

$s="select * from team";
$qres=mysqli_query($conn,$s);

$numTeam=mysqli_num_rows($qres);
$i=0;

for(;$i<$numTeam;$i=$i+1)
{
   $r = mysqli_fetch_assoc($qres);
   echo '<div class="team_name"> Team : ';
   echo $r["teamName"];
   echo "</div>";
   $Team = $r["teamNo"];
   echo "<h2> Committee Head</h2>";
   
   $s1 = "select * from teammem where mRole='Committee Head' and teamNo=$Team";
   
   $hres = mysqli_query($conn,$s1);
   $row = mysqli_fetch_assoc($hres);

   echo '<div class = "teamHead">';

   if($row)
   {
?>
    <div class="col-md-3 team_gd2">
        <div class="team_post">
            <div class="team_backt">
            </div>
            <img class="img-responsive" src="images/tm1.jpg"  alt=" ">
        </div>
        <h4><?php echo $row["mName"];?></h4>
        <p><?php echo $row["mRole"];?></p>
    </div>

    <?php
     if($r['asst'] == 1)
     {
        $q = "select * from teammem where mRole='Asst Committee Head' and teamNo=$Team";
        $h = mysqli_query($conn,$q);    
        $t = mysqli_fetch_assoc($h);

    ?>
    <div class="col-md-3 team_gd2">
        <div class="team_post">
            <div class="team_backt">
            </div>
            <img class="img-responsive" src="images/tm1.jpg"  alt=" ">
        </div>
        <h4><?php echo $t["mName"];?></h4>
        <p><?php echo "Assistant Committee Head";?></p>
    </div>
    
    <?php
     }
     else
    echo '<div class="col-md-3 team_gd2"></div>';
    ?>

    <div class="col-md-3 team_gd2"></div>
    <div class="col-md-3 team_gd2"></div>
    </div>
<?php
   }
   
   echo "<h2>";
   echo "Members";
   echo "</h2>";
   
   $s1 = "select * from teammem where mRole='Member' and teamNo=$Team";
   $hres = mysqli_query($conn,$s1);
   $nmem = mysqli_num_rows($hres);

   $j=0;

   echo '<div class = "teamMem">';
   for(;$j<$nmem;$j=$j+1)
   {
    $row = mysqli_fetch_assoc($hres);

?>
   <div class="col-md-3 team_gd2">
        <div class="team_post">
            <div class="team_backt">
            </div>
            <img class="img-responsive" src="images/tm1.jpg"  alt=" ">
        </div>
        <h4><?php echo $row["mName"];?></h4>
        <p><?php echo $row["mRole"];?></p>
    </div>
<?php
   }

   if($nmem%4!=0){
    $j=0;
    $b=4-$nmem%4;

    for(;$j<$b;$j=$j+1)
    {
        echo '<div class="col-md-3 team_gd2"></div>';
    }
        }
    echo "</div>";
}

echo "</div>";
echo'</div>';
?>