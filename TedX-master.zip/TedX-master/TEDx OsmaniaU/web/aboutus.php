<?php
echo(file_get_contents("webpages/lib.html"));
?>

<div class="banner-about">

<?php
echo(file_get_contents("webpages/header.html"));
echo(file_get_contents("webpages/about.html"));
?>