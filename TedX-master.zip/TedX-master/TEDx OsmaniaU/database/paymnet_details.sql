-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2018 at 12:30 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.1.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tedx`
--

-- --------------------------------------------------------

--
-- Table structure for table `paymnet_details`
--

CREATE TABLE `paymnet_details` (
  `ID` int(11) NOT NULL,
  `TXNID` varchar(30) NOT NULL,
  `FULLNAME` varchar(30) NOT NULL,
  `COLLEGE` varchar(40) NOT NULL,
  `MOBILENO` bigint(10) NOT NULL,
  `AMOUNT` varchar(30) NOT NULL,
  `DATE_1` varchar(30) NOT NULL,
  `EMAIL_ID` varchar(30) NOT NULL,
  `STATUS` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paymnet_details`
--

INSERT INTO `paymnet_details` (`ID`, `TXNID`, `FULLNAME`, `COLLEGE`, `MOBILENO`, `AMOUNT`, `DATE_1`, `EMAIL_ID`, `STATUS`) VALUES
(37, 'Txn92623995', 'Vikram', 'fassak', 2147483647, '200.00', '2018/12/12', 'vikramsooraj@gmail.com', 'success'),
(39, 'Txn46217528', 'laxman', 'fassak', 2147483647, '200.00', '2018/12/12', 'laxman.madipadige@gmail.com', 'success'),
(41, 'Txn8389935', 'laxman', 'fassak', 2147483647, '200.00', '2018/12/12', 'laxman.madipadige@gmail.com', 'success'),
(43, 'Txn66526885', 'Laxman Madipadige', 'fassak', 2147483647, '20.00', '2018/12/12', 'laxman.madipadige@gmail.com', 'success'),
(45, 'Txn83276913', 'Laxman', 'fassak', 2147483647, '200.00', '2018/12/12', 'laxman@gmail.com', 'success'),
(47, 'Txn49463073', 'laxman', 'fassak', 2147483647, '20.00', '2018/12/12', 'laxman@gmail.com', 'success'),
(48, 'Txn46995306', 'laxman', 'fassak', 2147483647, '620.00', '2018/12/12', 'laxman@gmail.com', 'success'),
(50, 'Txn12435563', 'laxman', 'fassak', 2147483647, '100.00', '2018/12/12', 'laxman.madipadige@gmail.com', 'success'),
(52, 'Txn56159593', 'Laxman Madipadige', 'fassak', 2147483647, '100.00', '2018/12/12', 'laxman.madipadige@gmail.com', 'success'),
(53, 'Txn36689405', 'Laxman', '', 0, '10.00', '2018/12/12', 'laxman.madipadige@gmail.com', 'success'),
(54, 'Txn7954032', 'laxman', '', 0, '20.00', '2018/12/12', 'laxman.madipadige@gmail.com', 'success'),
(55, 'Txn89263989', 'Agha', '', 0, '1000.00', '2018/12/15', 'aghamarshv.be20@uceou.edu', 'success'),
(58, 'Txn67649127', 'Aghamarsh varanasi', '', 0, '10.00', '2018/12/15', 'aghamarsh8@gmail.com', 'success'),
(65, 'Txn75463776', 'Aghamarsh varanasi', '', 9948558751, '10.00', '2018/12/15', 'aghamarsh8@gmail.com', 'success'),
(66, 'Txn72077712', 'Aghamarsh', '', 9948558751, '10.00', '2018/12/15', 'aghamarsh8@gmail.com', 'success'),
(69, 'Txn65673587', 'Aghamarsh varanasi', '', 8328353917, '10.00', '2018/12/15', 'aghamarsh8@gmail.com', 'success');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `paymnet_details`
--
ALTER TABLE `paymnet_details`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `TXNID` (`TXNID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `paymnet_details`
--
ALTER TABLE `paymnet_details`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
