-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2018 at 12:31 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.1.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tedx`
--

-- --------------------------------------------------------

--
-- Table structure for table `teammem`
--

CREATE TABLE `teammem` (
  `Sno` int(10) NOT NULL,
  `teamNo` int(10) NOT NULL,
  `mName` varchar(30) NOT NULL,
  `mRole` varchar(30) NOT NULL DEFAULT 'Member',
  `pic` longblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teammem`
--

INSERT INTO `teammem` (`Sno`, `teamNo`, `mName`, `mRole`, `pic`) VALUES
(1, 1, 'Najeebuddin Mohammed', 'Committee Head', NULL),
(2, 1, 'Tangirala Aneesh', 'Asst Committee Head', NULL),
(3, 1, 'Sowmya R', 'Member', NULL),
(4, 1, 'Sree Chandana', 'Member', NULL),
(5, 1, 'Mohammad Ali Amjad Hassan', 'Member', NULL),
(6, 1, 'Laxmi Gayathri Challa', 'Member', NULL),
(7, 1, 'Kalluri Manaswee Reddy', 'Member', NULL),
(8, 1, 'Areti Vineela', 'Member', NULL),
(9, 1, 'Ravva Sushanth Kumar', 'Member', NULL),
(10, 1, 'Rajshri Ragi', 'Member', NULL),
(11, 5, 'M V Sudhanshu ', 'Committee Head', NULL),
(12, 5, 'Kannedara Pallavi', 'Member', NULL),
(13, 5, 'Madihah Kazim', 'Member', NULL),
(14, 5, 'B Sai Swati Kiran', 'Member', NULL),
(15, 5, 'Kyatham Manaswini', 'Member', NULL),
(16, 5, 'M Navya Sree', 'Member', NULL),
(17, 5, 'Sneha Nomula', 'Member', NULL),
(18, 5, 'Mikkili Keerthana', 'Member', NULL),
(19, 5, 'Annamalla Harshini', 'Member', NULL),
(20, 5, 'Yelijala Sniya', 'Member', NULL),
(21, 5, 'B Rishitha', 'Member', NULL),
(22, 6, 'Mahaveer Suri', 'Committee Head', NULL),
(23, 6, 'Aluwala Raga Harshini', 'Member', NULL),
(24, 6, 'Suvan Tikku', 'Member', NULL),
(25, 6, 'Mohammed Mujtaba', 'Member', NULL),
(26, 6, 'Shivani Gandla', 'Member', NULL),
(27, 6, 'Patta Sai Prajesh', 'Member', NULL),
(28, 6, 'Vaibhavi Vadali', 'Member', NULL),
(29, 6, 'Sarthak A S', 'Member', NULL),
(30, 6, 'A Ankith Ram Sagar', 'Member', NULL),
(31, 6, 'Siri Balli', 'Member', NULL),
(32, 4, 'Srijay', 'Committee Head', NULL),
(33, 4, 'Lakshman', 'Member', NULL),
(34, 4, 'Aghamarsh Varanasi', 'Member', NULL),
(35, 4, 'Kalpana Satya', 'Member', NULL),
(36, 4, 'Krithika Bitla', 'Member', NULL),
(37, 4, 'Sasank', 'Member', NULL),
(38, 4, 'Abhishek', 'Member', NULL),
(39, 4, 'Pavan Kumar Lekkala', 'Member', NULL),
(40, 4, 'Katta Sushanth', 'Member', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `teammem`
--
ALTER TABLE `teammem`
  ADD PRIMARY KEY (`Sno`),
  ADD UNIQUE KEY `Sno` (`Sno`),
  ADD KEY `teamNo` (`teamNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `teammem`
--
ALTER TABLE `teammem`
  MODIFY `Sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `teammem`
--
ALTER TABLE `teammem`
  ADD CONSTRAINT `teammem_ibfk_1` FOREIGN KEY (`teamNo`) REFERENCES `team` (`teamNo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
