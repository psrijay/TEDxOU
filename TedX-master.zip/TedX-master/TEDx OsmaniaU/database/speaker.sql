-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 12, 2018 at 11:27 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `event`
--

-- --------------------------------------------------------

--
-- Table structure for table `speaker`
--

DROP TABLE IF EXISTS `speaker`;
CREATE TABLE IF NOT EXISTS `speaker` (
  `year` year(4) NOT NULL,
  `sname` varchar(30) NOT NULL,
  `sdesc` text NOT NULL,
  `simg` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `speaker`
--

INSERT INTO `speaker` (`year`, `sname`, `sdesc`, `simg`) VALUES
(2019, 'speaker1', 'he is a famous person and pioneer in his work.', 'C:\\wamp64\\www\\TedX-master\\TedX-master\\TEDx OsmaniaU\\web\\images\\tm3.jpg'),
(2019, 'speaker2', 'He is a famous speaker and a pioneer in his work', 'C:\\wamp64\\www\\TedX-master\\TedX-master\\TEDx OsmaniaU\\web\\images\\tm3.jpg'),
(2019, 'speaker3', 'He is a famous speaker and a pioneer in his work', 'C:\\wamp64\\www\\TedX-master\\TedX-master\\TEDx OsmaniaU\\web\\images\\tm3.jpg\r\n'),
(2019, 'speaker4', 'He is a famous speaker and a pioneer in his work', 'C:\\wamp64\\www\\TedX-master\\TedX-master\\TEDx OsmaniaU\\web\\images\\tm3.jpg'),
(2019, 'speaker5', 'He is a famous speaker and a pioneer in his work', 'C:\\wamp64\\www\\TedX-master\\TedX-master\\TEDx OsmaniaU\\web\\images\\tm3.jpg'),
(2019, 'speaker6', 'He is a famous speaker and a pioneer in his work', 'C:\\wamp64\\www\\TedX-master\\TedX-master\\TEDx OsmaniaU\\web\\images\\tm3.jpg'),
(2019, 'speaker7', 'He is a famous speaker and a pioneer in his work', 'C:\\wamp64\\www\\TedX-master\\TedX-master\\TEDx OsmaniaU\\web\\images\\tm3.jpg'),
(2019, 'speaker8', 'He is a famous speaker and a pioneer in his work', 'C:\\wamp64\\www\\TedX-master\\TedX-master\\TEDx OsmaniaU\\web\\images\\tm3.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
