<?php
session_start();

require 'dbconfig.php';
$email = $_SESSION['mail'];

$sql= "select * from `paymnet_details` where `email_id`='$email'";
$q=mysqli_query($conn,$sql);

$row ;

if($q)
{
    $row = mysqli_fetch_assoc($q);    
}
else
{
    echo "Invalid email id";
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Download Ticket</title>
<link href="https://fonts.googleapis.com/css?family=Cabin|Indie+Flower|Inknut+Antiqua|Lora|Ravi+Prakash" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"  />
    <link href="css/main.css" rel="stylesheet" media="all">
</head>
<body>
	
<div class="main">
<div class="container"><br><br>
  <h1 class="upcomming">TEDx OsmaniaU Ticket</h1>
  <div class="item">
    <div class="item-right">
      <h2 class="num">27</h2>
      <p class="day">JAN</p>
      <span class="up-border"></span>
      <span class="down-border"></span>
    </div> <!-- end item-right -->
    
    <div class="item-left">
      <p class="event"><img src="http://localhost/TedX/payment/images/TEDx logo.png" style="width:400px;height:100px;"/></p>
      <h2 class="title"><?php echo $row['FULLNAME']; ?></h2>
      <br>
      <div class="sce">
        <div class="icon">
          <i class="fa fa-table"></i>
        </div>
        <p>10:00AM Onwards</p>
      </div>
      <div class="fix"></div><br>
      <div class="loc">
        <div class="icon">
          <i class="fa fa-map-marker"></i>
        </div>
        <p>Tagore Auditoruim<br/>Osmania Univeristy, Hyd</p>
      </div>
      <div class="fix"></div>
      <button class="tickets"><b>TxnID : <?php echo $row['TXNID']; ?></b></button>
    </div> <!-- end item-right -->
  </div> <!-- end item -->
  
</div>
</div>
<button id="print">Print</button>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/printThis.js"></script>
	<script>
	$('#print').click(function()
	{
		$('.main').printThis({
			debug: false,               // show the iframe for debugging
        importCSS: true,            // import parent page css
        importStyle: false,         // import style tags
        printContainer: true,       // print outer container/$.selector
        loadCSS: "http://localhost/TedX/payment/css/main.css",
        pageTitle: "",              // add title to print page
        removeInline: false,        // remove inline styles from print elements
        removeInlineSelector: "*",  // custom selectors to filter inline styles. removeInline must be true
        printDelay: 333,            // variable print delay
        header:null,               // prefix to html
        footer: null,               // postfix to html
        base: false,                // preserve the BASE tag or accept a string for the URL
        formValues: true,           // preserve input/form values
        canvas: false,              // copy canvas content
        doctypeString: '<!DOCTYPE html>', // enter a different doctype for older markup
        removeScripts: false,       // remove script tags from print content
        copyTagClasses: false,      // copy classes from the html & body tag
        beforePrintEvent: null,     // callback function for printEvent in iframe
        beforePrint: null,          // function called before iframe is filled
        afterPrint: null
		});
	})
</script>
</body>

</html>
<?php
	
?>