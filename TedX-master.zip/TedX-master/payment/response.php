<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tedx";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else
{

$postdata = $_POST;
$msg = '';
if (isset($postdata ['key'])) {
  $key        =   $postdata['key'];
  // $salt       =   $postdata['salt'];
  $salt       = 'dA3XIu0hQq';
  $txnid        =   $postdata['txnid'];
  $amount         =   $postdata['amount'];
  $productInfo      =   $postdata['productinfo'];
  $firstname        =   $postdata['firstname'];
  $email            = $postdata['email'];
  $mob = $postdata['phone'];
  $udf5       =   $postdata['udf5'];
  $mihpayid     = $postdata['mihpayid'];
  $status       =   $postdata['status'];
  $resphash       =   $postdata['hash'];
  $clg = $postdata['coll'];
  $date = date("Y/m/d");

  //Calculate response hash to verify 
  $keyString        =   $key.'|'.$txnid.'|'.$amount.'|'.$productInfo.'|'.$firstname.'|'.$email.'|||||'.$udf5.'|||||';
  $keyArray         =   explode("|",$keyString);
  $reverseKeyArray  =   array_reverse($keyArray);
  $reverseKeyString = implode("|",$reverseKeyArray);
  $CalcHashString   =   strtolower(hash('sha512', $salt.'|'.$status.'|'.$reverseKeyString));
  
  
  if ($status == 'success'  && $resphash == $CalcHashString) {
    $sql = "INSERT INTO paymnet_details(ID,TXNID,FULLNAME,COLLEGE,MOBILENO,AMOUNT, DATE_1, EMAIL_ID, STATUS)
            VALUES ('','$txnid', '$firstname','$clg','$mob','$amount','$date','$email','$status')";
           
           if (mysqli_query($conn, $sql)) {
    ?>

            <script type="text/javascript" src="https://code.jquery.com/jquery-1.8.2.js"></script>
            <style type="text/css">
            #overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #000;
            filter:alpha(opacity=70);
            -moz-opacity:0.7;
            -khtml-opacity: 0.7;
            opacity: 0.7;
            z-index: 100;
            display: none;
            }
            .cnt223 a{
            text-decoration: none;
            }
            .popup{
            width: 100%;
            margin: 0 auto;
            display: none;
            position: fixed;
            z-index: 101;
            }
            .cnt223{
            min-width: 600px;
            width: 600px;
            min-height: 150px;
            margin: 100px auto;
            background: #f3f3f3;
            position: relative;
            z-index: 103;
            padding: 15px 35px;
            border-radius: 5px;
            box-shadow: 0 2px 5px #000;
            }
            .cnt223 .x:hover{
            cursor: pointer;
            }
            </style>
            <script type='text/javascript'>
            $(function(){
            var overlay = $('<div id="overlay"></div>');
            overlay.show();
            overlay.appendTo(document.body);
            $('.popup').show();
            $('.close').click(function(){
            $('.popup').hide();
            overlay.appendTo(document.body).remove();
            return false;
            });
            $('.x').click(function(){
            $('.popup').hide();
            overlay.appendTo(document.body).remove();
            return false;
            });
            });
            </script>
            <div class='popup'>
            <div class='cnt223'>
            <h1>TEDx OsmaniaU</h1>
            <p>
            Thank you for Buying the tickets.Please Login to download your tickets.
            <br/>
            <br/>
            <a href='../TEDx OsmaniaU/web/login_reg.php'>Login</a>
            </p>
            </div>
            </div>
            <?php

$msg = "Transaction Successful and Hash Verified...";
}
  //Do success order processing here...
}
else {
  //tampered or failed
  $msg = "Payment failed for Hash not verified...";
} 
}
else exit(0);
}
?>